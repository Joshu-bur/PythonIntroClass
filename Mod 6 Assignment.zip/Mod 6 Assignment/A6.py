
# Title: Assignment 6
# Dev: Joshua Burwell
# Date:  5/7/2018
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   JBurwell, 04/27/2018, modified for A5
#   JBurwell, 05/06/2018, simplified code into function
#		Used Assignment 5 answer as a guide for Assignment 6 -Thanks for the help!
#-------------------------------------------------#

import csv

#define variables
objectpath = "C:\_PythonClass\Todo.txt"
str_data = ""
str_dataint = ""
dic_row = {}
list_tbl = []

class procedure(object):


	def menu():
		print ("""
		Menu of Options\n
		1: Show Current List\n
		2: Add More To Your List\n
		3: Remove/Complete a Task\n
		4: Save Your List\n
		5: Exit\n
		""")
		#Get Input
		str_option = str(input("Select a command between 1 and 5: "))
		print()
		return str_option


	def new():
		str_task = str(input("Task: "))
		str_task = str_task.capitalize()
		str_priority = str(input("High or Low priority?: "))
		data = (str_task,str_priority)
		return data, str_task, str_priority


	def list(table):
		str_dataint = ""
		for item in table:
			str_dataint = str(item)
			str_dataint = re.sub("[\[\]()']", "", str_dataint)
			print(str_dataint)

#Load data and each row from txt file into dictionary
print("\nWelcome to your To Do List!\n")
with open("Todo.txt", mode="r") as f:
	reader = csv.reader(f)
	dic_row = {rows[0]:rows[1] for rows in reader}

#make row to table
for key, value in dic_row.items():
	temp = (key,value)
	list_tbl.append(temp)

#show menu
while(True):
	str_option = procedure.menu()

	#show list
	if (str_option.strip() == '1'):
		procedure.list(list_tbl)

	#add
	elif(str_option.strip() == '2'):
		data, str_task, str_priority = procedure.new()
		list_tbl.append(data)
		print("\nTask: ", str_task)
		print("Priority: ", str_priority)
		print("Added to your To Do list.")

	#Remove
	elif(str_option == '3'):
		strDelTask = str(input("Which task have you completed?: "))
		for task in list_tbl:
			if (task[0] == strDelTask.capitalize()):
				list_tbl.remove(task)
				print("\nTask", strDelTask, "has been removed from your list.")

	#saves to file
	elif(str_option == '4'):
		for item in list_tbl:
			str_data += str(item) + "\n"
			str_data = re.sub("[\[\]()']", "", str_data)
			str_data = str_data.replace(", ", r",")
		objectpath = open("./Todo.txt", "w")
		objectpath.write(str_data)
		objectpath.close()
		str_data = ""
		print("All Tasks have been saved to 'Todo.txt'")

	#exit
	elif (str_option == '5'):
		break
